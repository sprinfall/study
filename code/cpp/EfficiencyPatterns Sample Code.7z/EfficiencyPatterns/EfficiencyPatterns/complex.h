#ifndef COMPLEX_H_
#define COMPLEX_H_

#include <iostream>

class Complex {
  friend Complex operator+(const Complex&, const Complex&);

public:
  Complex(double real = 0.0, double imag = 0.0)
      : real_(real), imag_(imag) {
    std::cout << "Complex()" << std::endl;
  }

  Complex(const Complex& rhs)
      : real_(rhs.real_), imag_(rhs.imag_) {
    std::cout << "Complex(Complex)" << std::endl;
  }

  Complex& operator=(const Complex& rhs) {
    std::cout << "operator=()" << std::endl;

    if (&rhs != this) {
      real_ = rhs.real_;
      imag_ = rhs.imag_;
    }
    return *this;
  }

  ~Complex() {
    std::cout << "~Complex()" << std::endl;
  }

private:
  double real_;
  double imag_;
};

Complex operator+(const Complex& lhs, const Complex& rhs) {
  Complex c;
  c.real_ = lhs.real_ + rhs.real_;
  c.imag_ = lhs.imag_ + rhs.imag_;
  return c;
}

//Complex operator+(const Complex& lhs, const Complex& rhs) {
//  return Complex(lhs.real_ + rhs.real_, lhs.imag_ + rhs.imag_);
//}

#endif // COMPLEX_H_
