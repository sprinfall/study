#include "complex.h"
#include <iostream>

int main() {
  Complex a;
  Complex b;
  Complex c = a + b;

  return 0;
}
