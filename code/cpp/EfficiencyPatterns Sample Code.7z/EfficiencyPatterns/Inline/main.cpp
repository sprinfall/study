
// Test inline performance.

//inline
int calc(int a, int b) {
  return a + b;
}

int main() {
  int x[1000];
  int y[1000];
  int z[1000];
  for (int i = 0; i < 1000; ++i) {
    for (int j = 0; j < 1000; ++j) {
      for (int k = 0; k < 1000; ++k) {
        z[i] = calc(y[j], x[k]);
      }
    }
  }

  return 0;
}
