#include <vector>
#include <iostream>
using namespace std;

void TestVector1() {
  vector<int> ints;
  cout << "(" << ints.size() << ", " << ints.capacity() << ")" << endl;

  ints.push_back(1);
  cout << "(" << ints.size() << ", " << ints.capacity() << ")" << endl;

  ints.push_back(2);
  ints.push_back(3);
  ints.push_back(4);
  ints.push_back(5);
  ints.push_back(6);
  ints.push_back(7);
  cout << "(" << ints.size() << ", " << ints.capacity() << ")" << endl;

  ints.shrink_to_fit(); // C++11
  cout << "After shrink to fit." << endl;
  cout << "(" << ints.size() << ", " << ints.capacity() << ")" << endl;

  ints.push_back(8);
  cout << "(" << ints.size() << ", " << ints.capacity() << ")" << endl;
}

void TestVector2() {
  vector<int> ints1;
  ints1.resize(3);
  ints1[0] = 1;
  ints1[1] = 2;
  ints1[2] = 3;
  cout << "(" << ints1.size() << ", " << ints1.capacity() << ")" << endl;

  vector<int> ints2;
  ints2.push_back(1);
  ints2.push_back(2);
  ints2.push_back(3);
  cout << "(" << ints2.size() << ", " << ints2.capacity() << ")" << endl;
}


int main() {
  //TestVector1();
  //TestVector2();
}
