#ifndef STRING_H_
#define STRING_H_

#include <cstring>

class String {
public:
  String(const char* str = "") {
    Assign(str);
  }

  String(const String& rhs) {
    Assign(rhs.data_);
  }

  ~String() {
    delete[] data_;
  }

  String& operator=(const String& rhs) {
    if (&rhs != this) {
      delete[] data_;
      Assign(rhs.data());
    }
    return *this;
  }

  const char* data() const {
    return data_;
  }

  size_t length() const {
    return length_;
  }

private:
  void Assign(const char* str) {
    length_ = strlen(str);
    data_ = new char[length_ + 1];
    memcpy(data_, str, length_);
    data_[length_] = '\0';
  }

private:
  char* data_;
  size_t length_;
};

//bool operator==(const String& lhs, const String& rhs);
//bool operator==(const String& lhs, const char* rhs);

#endif // STRING_H_
