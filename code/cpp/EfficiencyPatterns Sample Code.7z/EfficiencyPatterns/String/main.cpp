#include "./string.h"
#include <iostream>

int main() {
  String a = "a";
  //String b;
  //b = a;
  //std::cout << b.data() << std::endl;

  return 0;
}
